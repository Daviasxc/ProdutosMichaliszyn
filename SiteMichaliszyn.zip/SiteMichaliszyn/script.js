let cart = JSON.parse(localStorage.getItem('cart')) || [];
updateCart();

function addToCart(item, price) {
    cart.push({ name: item, price: price });
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
    createHeartExplosion(event);
    alert(`${item} adicionado ao carrinho! 🐦‍⬛`);
}

function updateCart() {
    const total = cart.reduce((sum, item) => sum + item.price, 0).toFixed(2);
    document.getElementById('cartTotal').textContent = `${cart.length} itens (R$ ${total})`;
}


function createHeartExplosion(e) {
    for (let i = 0; i < 6; i++) {
        let heart = document.createElement('span');
        heart.textContent = '🐦‍⬛';
        heart.className = 'heart';
        heart.style.left = `${e.pageX + Math.random() * 15 - 7}px`;
        heart.style.top = `${e.pageY + Math.random() * 15 - 7}px`;
        document.body.appendChild(heart);
        setTimeout(() => heart.remove(), 2000);
    }
}


function createEmoRain() {
    setInterval(() => {
        let rain = document.createElement('span');
        rain.textContent = '🐦‍⬛';
        rain.className = 'emo-rain';
        rain.style.left = `${Math.random() * window.innerWidth}px`;
        rain.style.top = '0px';
        document.body.appendChild(rain);
        setTimeout(() => rain.remove(), 3000);
    }, 500);
}


document.addEventListener('mousemove', (e) => {
    const crow = document.querySelector('.crow-mascot');
    crow.style.transform = `translate(${e.clientX / 80}px, ${e.clientY / 80}px)`;
});


window.addEventListener('load', () => {
    document.querySelectorAll('.fade-in').forEach((el, i) => {
        el.style.animationDelay = `${i * 0.2}s`;
    });
    createEmoRain(); 
});